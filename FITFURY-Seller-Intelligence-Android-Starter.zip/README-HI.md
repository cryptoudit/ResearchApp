# FITFURY Seller Intelligence – Android MVP 1.0

यह **native Android application source project** है। इसमें कोई website या web dashboard शामिल नहीं है।

## इस शुरुआती build में क्या काम करता है?
- Amazon India / Flipkart marketplace selector (research workspace selector)
- Offline keyword bank: keywords और notes save/delete
- Local keyword idea generator (यह live marketplace search volume नहीं बताता)
- Listing draft assistant: product features और keywords से title/bullets/description draft
- Profit estimate calculator
- Local saved data (SharedPreferences)

## अभी क्या शामिल नहीं है?
- Live Amazon/Flipkart search volume, competitor sales या rank data
- Amazon SP-API / Flipkart seller API connection
- Cloud sync / AI API integration
- Play Store signed release build

इनके लिए authorized API access और secure backend credentials की जरूरत होगी। इस MVP में कोई fake live metrics नहीं दिखाए जाते।

## Android phone से APK बनाना – GitHub Actions
1. GitHub पर नया repository बनाएं, उदाहरण: `fitfury-seller-intelligence`.
2. ZIP extract करें और उसके अंदर की सभी files/folders repository के root में upload करें। ZIP को केवल ZIP file की तरह upload न करें।
3. सुनिश्चित करें कि `app`, `.github`, `build.gradle.kts`, `settings.gradle.kts` और `gradle.properties` root में दिखें।
4. GitHub repository खोलें → **Actions** tab.
5. अगर workflow disabled हो तो **I understand my workflows, go ahead and enable them** चुनें।
6. **Build FITFURY Android APK** workflow खोलें → **Run workflow**.
7. Build complete होने पर run खोलें → **Artifacts** → `FITFURY-Seller-Intelligence-debug` download करें।
8. Downloaded artifact ZIP extract करें। अंदर `app-debug.apk` मिलेगा।
9. APK tap करें और Android prompt आने पर browser/files app को **Install unknown apps** permission दें। फिर Install करें।

## Local build (Android Studio)
- Android Studio में project folder खोलें.
- JDK 17 और Android SDK Platform 35 install रखें.
- Gradle sync करें.
- Build → Build Bundle(s) / APK(s) → Build APK(s).

## Notes
- Debug APK testing के लिए है; Play Store/public distribution के लिए release signing और privacy/security review जरूरी है.
- Profit calculator simplified estimate है। Marketplace fee, GST treatment, TCS/TDS, returns, ads और settlement deductions को actual reports से verify करें.
- Keyword ideas are generated locally from the seed phrase and must be validated on the relevant marketplace.
