# FITFURY Seller Intelligence — Android starter MVP

Android-only native application starter for Amazon India + Flipkart.

## Current build includes
- Native Kotlin + Jetpack Compose UI
- Dashboard and navigation
- Product URL / ASIN / FSN analyzer input workspace
- My listing vs competitor comparison input workspace
- Keyword research draft phrase generator (explicitly not live volume data)
- Listing brief workspace
- GitHub Actions workflow to build a debug APK

## Important status
This is a functional UI starter/prototype, NOT the finished live research service.
It currently does not fetch marketplace data, actual orders, competitor sales, search volume,
rank history, live bids, or AI-generated listings. No metrics are fabricated.

To enable live features, a managed backend/data connector must be implemented and deployed.
Public listing observations must respect marketplace access rules. Private seller orders,
advertising reports and account metrics require one-time authorized seller-account access
or report imports. API secrets must stay on the backend, never inside the APK.

## Build APK from Android phone using GitHub
1. Extract this ZIP.
2. Create a GitHub repository.
3. Upload the extracted project files/folders (not the ZIP itself).
4. Open Actions and run "Build FITFURY Android APK".
5. Open the completed workflow run and download artifact
   `FITFURY-Seller-Intelligence-debug`.
6. Extract the artifact ZIP and install `app-debug.apk` on Android.
7. Allow installation from the browser/file manager if Android asks.

## Technical
- Kotlin, Jetpack Compose, Material 3
- minSdk 26, targetSdk 35
- JDK 17
