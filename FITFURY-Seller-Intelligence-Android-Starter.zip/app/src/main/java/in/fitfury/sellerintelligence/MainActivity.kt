package in.fitfury.sellerintelligence

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF101827)
private val Panel = Color(0xFF1B2638)
private val Mint = Color(0xFF16C79A)
private val Muted = Color(0xFF9AA8BC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SellerApp() }
    }
}

@Composable
fun SellerApp() {
    var tab by remember { mutableStateOf("Home") }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Mint, background = Navy, surface = Panel,
        onPrimary = Navy, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Navy,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Home", "Analyze", "Compare", "Keywords", "Listing").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {
                                Icon(
                                    when(item) {
                                        "Home" -> Icons.Default.Dashboard
                                        "Analyze" -> Icons.Default.Search
                                        "Compare" -> Icons.Default.CompareArrows
                                        "Keywords" -> Icons.Default.Key
                                        else -> Icons.Default.EditNote
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            when(tab) {
                "Home" -> HomeScreen(Modifier.padding(padding)) { tab = it }
                "Analyze" -> AnalyzeScreen(Modifier.padding(padding))
                "Compare" -> CompareScreen(Modifier.padding(padding))
                "Keywords" -> KeywordScreen(Modifier.padding(padding))
                else -> ListingScreen(Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun Page(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(top = 20.dp, bottom = 24.dp)) {
        item { contentColumn(content) }
    }
}
@Composable
private fun contentColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
}
@Composable
fun Header(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text(subtitle, color = Muted, fontSize = 13.sp)
    }
}
@Composable
fun PanelCard(title: String, body: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 16.sp)
            body()
        }
    }
}
@Composable
fun HomeScreen(modifier: Modifier, navigate: (String) -> Unit) {
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("FITFURY", color = Mint, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Text("Seller Intelligence", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("Amazon India • Flipkart", color = Muted)
            }
            Surface(color = Color(0xFF173B37), shape = RoundedCornerShape(50.dp)) {
                Text("MVP 0.1", color = Mint, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 11.sp)
            }
        }
        PanelCard("Your growth workspace") {
            Text("Research products, compare listings, discover keyword opportunities and prepare better SEO content.", color = Muted)
            Button(onClick = { navigate("Analyze") }, modifier = Modifier.fillMaxWidth()) { Text("Analyze a product") }
        }
        Text("TOOLS", color = Muted, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        val tools = listOf(
            Triple("Product URL / ASIN Analyzer", "Inspect product details and listing gaps", "Analyze"),
            Triple("Competitor Comparison", "Compare your listing with competitors", "Compare"),
            Triple("Keyword Intelligence", "Build relevant SEO and PPC keyword ideas", "Keywords"),
            Triple("AI Listing Studio", "Create and improve listing drafts", "Listing")
        )
        tools.forEach { (title, desc, destination) ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Panel),
                modifier = Modifier.fillMaxWidth().clickable { navigate(destination) },
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(desc, color = Muted, fontSize = 12.sp)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = Mint)
                }
            }
        }
        Text("Data honesty: private competitor orders and exact search volumes are not public by default. This starter app does not fabricate them.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun AnalyzeScreen(modifier: Modifier) {
    var market by remember { mutableStateOf("Amazon India") }
    var identifier by remember { mutableStateOf("") }
    var result by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Header("Product Analyzer", "Paste an ASIN, FSN or product URL")
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            listOf("Amazon India", "Flipkart").forEachIndexed { i, value ->
                SegmentedButton(selected = market == value, onClick = { market = value; result = false }, shape = SegmentedButtonDefaults.itemShape(i, 2)) { Text(if (i == 0) "Amazon" else "Flipkart") }
            }
        }
        OutlinedTextField(value = identifier, onValueChange = { identifier = it; result = false }, modifier = Modifier.fillMaxWidth(), label = { Text("Product URL / ASIN / FSN") }, placeholder = { Text("Paste product link or identifier") }, minLines = 2)
        Button(onClick = { result = identifier.isNotBlank() }, enabled = identifier.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Search, null); Spacer(Modifier.width(8.dp)); Text("Prepare analysis") }
        if (result) {
            PanelCard("Analysis workspace created") {
                Text("Marketplace: $market", color = Mint)
                Text("Input: $identifier", color = Muted)
                Text("Next integration: retrieve permitted public listing fields and attach source + last-updated timestamps.", color = Color.White)
                Text("Orders / sales: only show actual values from authorized seller reports. Competitor order counts remain unavailable unless a clearly labelled estimate source exists.", color = Muted, fontSize = 12.sp)
            }
            PanelCard("Analysis checklist") {
                listOf("Product title and attributes", "Price, rating and review count", "Category rank, if exposed", "Image and content audit", "Keyword coverage and gaps", "Competitor opportunities").forEach { CheckLine(it) }
            }
        } else {
            PanelCard("What the analyzer will assess") {
                listOf("Listing content and product attributes", "Public price, ratings and reviews", "Available category/search ranking signals", "Relevant keyword and competitor gaps", "Improvement recommendations").forEach { CheckLine(it) }
            }
        }
    }
}

@Composable
fun CheckLine(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.CheckCircle, null, tint = Mint, modifier = Modifier.size(17.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, color = Color.White, fontSize = 13.sp)
    }
}

@Composable
fun CompareScreen(modifier: Modifier) {
    var mine by remember { mutableStateOf("") }
    var competitors by remember { mutableStateOf("") }
    var compare by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Header("Listing Comparison", "Your product vs up to 10 competitors")
        OutlinedTextField(mine, { mine = it; compare = false }, modifier = Modifier.fillMaxWidth(), label = { Text("My listing URL / ASIN / FSN") }, minLines = 2)
        OutlinedTextField(competitors, { competitors = it; compare = false }, modifier = Modifier.fillMaxWidth(), label = { Text("Competitor URLs / ASINs (one per line)") }, minLines = 4)
        Button(onClick = { compare = mine.isNotBlank() && competitors.isNotBlank() }, enabled = mine.isNotBlank() && competitors.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.CompareArrows, null); Spacer(Modifier.width(8.dp)); Text("Set up comparison") }
        if (compare) {
            PanelCard("Comparison workspace ready") {
                Text("Your listing: $mine", color = Mint)
                Text("Competitor inputs: ${competitors.lines().count { it.isNotBlank() }}", color = Muted)
                listOf("Title relevance", "Keyword coverage", "Images and gallery", "Bullet points / attributes", "Price and review signals", "Listing completeness").forEach { CheckLine(it) }
                Text("This prototype prepares the comparison inputs; live retrieval and scoring require marketplace data integrations.", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun KeywordScreen(modifier: Modifier) {
    var product by remember { mutableStateOf("") }
    var seed by remember { mutableStateOf("") }
    var generated by remember { mutableStateOf(false) }
    val suggestions = remember(seed, product, generated) {
        if (!generated) emptyList() else listOf(
            "$seed for ecommerce packaging",
            "$seed price",
            "buy $seed online",
            "$seed for business",
            "best quality $seed",
            "$seed supplier India"
        ).filter { it.isNotBlank() }
    }
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Header("Keyword Intelligence", "SEO and PPC research workspace")
        OutlinedTextField(product, { product = it; generated = false }, modifier = Modifier.fillMaxWidth(), label = { Text("Product name / category") })
        OutlinedTextField(seed, { seed = it; generated = false }, modifier = Modifier.fillMaxWidth(), label = { Text("Seed keyword") })
        Button(onClick = { generated = product.isNotBlank() && seed.isNotBlank() }, enabled = product.isNotBlank() && seed.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Create keyword draft") }
        if (generated) {
            PanelCard("Starter phrase ideas — not live search-volume data") {
                suggestions.forEach { Text("• $it", color = Color.White) }
                Text("Live search demand, keyword rank and bid recommendations will only appear after verified data-source integration.", color = Muted, fontSize = 12.sp)
            }
            PanelCard("Keyword groups") {
                CheckLine("SEO: high relevance and natural product fit")
                CheckLine("PPC: buyer intent and testable campaign targets")
                CheckLine("Negative: irrelevant searches to exclude")
            }
        } else {
            PanelCard("Research outputs planned") {
                CheckLine("Main and long-tail keywords")
                CheckLine("Hindi / English / Hinglish variations")
                CheckLine("Competitor keyword gaps")
                CheckLine("Broad, phrase and exact PPC grouping")
                CheckLine("Negative keyword candidates")
            }
        }
    }
}

@Composable
fun ListingScreen(modifier: Modifier) {
    var product by remember { mutableStateOf("") }
    var features by remember { mutableStateOf("") }
    var draft by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Header("AI Listing Studio", "Prepare your product listing brief")
        OutlinedTextField(product, { product = it; draft = false }, modifier = Modifier.fillMaxWidth(), label = { Text("Product name") })
        OutlinedTextField(features, { features = it; draft = false }, modifier = Modifier.fillMaxWidth(), label = { Text("Features, dimensions and key specifications") }, minLines = 4)
        Button(onClick = { draft = product.isNotBlank() && features.isNotBlank() }, enabled = product.isNotBlank() && features.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Prepare listing brief") }
        if (draft) {
            PanelCard("Listing brief saved in this session") {
                Text("Product: $product", color = Mint)
                Text("Specifications: $features", color = Color.White)
                Text("Draft sections: SEO title • 5 bullets • description • backend terms • attributes • image brief.", color = Muted)
                Text("This starter build does not call a live AI provider yet. AI generation will be connected through a managed service; no API key will be placed in the APK.", color = Muted, fontSize = 12.sp)
            }
        } else {
            PanelCard("Listing deliverables") {
                CheckLine("Marketplace-compliant SEO title")
                CheckLine("Five benefit-led bullet points")
                CheckLine("Product description and attributes")
                CheckLine("Backend search terms")
                CheckLine("Image and infographic plan")
                CheckLine("Keyword stuffing and compliance audit")
            }
        }
    }
}
